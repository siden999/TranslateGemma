# TranslateGemma 安裝說明（超簡單版）

這份說明是給第一次使用的人看的。照做就能用。

---

## 你需要準備的東西
- 一台電腦（Windows 或 macOS）
- Chrome 瀏覽器
- 可以上網下載檔案
- Python 3.10～3.12（建議 Python 3.12）

---

## 第 1 步：下載並解壓縮
1. 到 GitHub 下載 zip 檔
2. 解壓縮（雙擊 zip 就會解開）
3. 你會看到一個資料夾（裡面有 `launcher`、`extension`）

---

## 第 2 步：安裝 Launcher（小幫手）
> Launcher 是「背景小程式」，用來啟動翻譯伺服器。

### macOS
1. 進到資料夾裡的 `launcher`
2. **雙擊** `install_mac.command`
3. 等它跑完（會先安裝 Launcher 與 server 環境並啟動 Launcher；模型會在你第一次於 Chrome 擴充按「啟動」時下載）
4. 之後請從 `~/Library/Application Support/TranslateGemma/extension` 載入 Chrome 未封裝擴充
5. 如果仍顯示「Launcher 未啟動」，先看 `~/Library/Application Support/TranslateGemma/launcher/launcher.log`

### Windows
1. 進到資料夾裡的 `launcher`
2. **右鍵** `install_win.ps1` → 選「使用 PowerShell 執行」
3. 如果跳出警告，按「允許」
4. 等它跑完（安裝器會先安裝 Launcher 與 server 環境並啟動 Launcher；模型會在你第一次於 Chrome 擴充按「啟動」時下載）
5. 之後請從 `%LOCALAPPDATA%\TranslateGemma\extension` 載入 Chrome 未封裝擴充
6. 如果 Chrome 已經有舊版 TranslateGemma，請先在 `chrome://extensions/` 移除舊版，再載入上方固定位置
7. 如果仍顯示「Launcher 未啟動」或「啟動橋接器未安裝」，先重新執行 `install_win.ps1`，再看 `%LOCALAPPDATA%\TranslateGemma\launcher\launcher.log`

---

## 第 3 步：安裝 Chrome 擴充
1. 打開 Chrome
2. 在網址列輸入：`chrome://extensions/`
3. 右上角打開「開發者模式」
4. 按「載入未封裝項目」
5. 選擇固定安裝位置裡的 `extension` 資料夾
6. 如果你是從舊版升級，建議先移除舊版 TranslateGemma，再載入固定安裝位置的 `extension` 資料夾

完成後，右上角會出現 TranslateGemma 圖示。

---

## 第 4 步：開始使用
1. 打開 YouTube
2. 點右上角 TranslateGemma 圖示
3. 按「啟動」（若 Launcher 尚未啟動，擴充會先嘗試自動喚起；第一次會先下載模型）
4. 開啟影片字幕（CC）
5. 看到翻譯就成功了 ✅

---

## 常見小問題
**Q1：按了啟動沒反應？**
- 第一次會下載 2～3GB 模型，請保持網路連線並等待下載進度
- macOS 若一直顯示「Launcher 未啟動」，先查看 `~/Library/Application Support/TranslateGemma/launcher/launcher.log`
- Windows 若一直顯示「Launcher 未啟動」，先查看 `%LOCALAPPDATA%\TranslateGemma\launcher\launcher.log`

**Q2：Windows 顯示「啟動橋接器未安裝」？**
- 重新執行 `launcher\install_win.ps1`
- 到 `chrome://extensions/` 移除舊版 TranslateGemma
- 重新「載入未封裝項目」，選 `%LOCALAPPDATA%\TranslateGemma\extension`
- 如果仍失敗，查看 `%LOCALAPPDATA%\TranslateGemma\launcher\launcher.log`

**Q3：重開機後還要再按啟動嗎？**
- 需要。Launcher 會自動在背景啟動，但伺服器預設是「關閉」，要你按一次啟動。

**Q4：看不到翻譯？**
- 重新整理 YouTube 頁面再試一次

---

如果還是不會用，你把畫面截圖傳給我們就好。
