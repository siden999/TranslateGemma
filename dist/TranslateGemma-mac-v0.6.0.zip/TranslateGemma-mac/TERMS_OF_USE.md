# TranslateGemma Terms of Use

By installing or using TranslateGemma, you agree to comply with the Gemma Terms of Use
and the Gemma Prohibited Use Policy provided with this software.

You must not use TranslateGemma or any output from it in a way that violates the
Gemma Prohibited Use Policy. You are responsible for ensuring your use complies
with all applicable laws and the Gemma Terms of Use.

If you do not agree, do not install or use this software.

References:
- GEMMA_TERMS_OF_USE.md
- GEMMA_PROHIBITED_USE_POLICY.md
- NOTICE
